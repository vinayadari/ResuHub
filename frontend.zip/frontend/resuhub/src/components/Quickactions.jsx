import React from 'react';
import { Plus, Zap, Download } from 'lucide-react';

/**
 * QuickActions Component - Displays action buttons for common tasks
 * 
 * @param {Object} props
 * @param {boolean} [props.isLoaded=true] - Controls animation state
 * @param {number} [props.delay=0] - Animation delay in ms
 * @param {Function} [props.onUpload] - Callback for upload action
 * @param {Function} [props.onReview] - Callback for AI review action
 * @param {Function} [props.onExport] - Callback for export action
 */
const QuickActions = ({ 
  isLoaded = true, 
  delay = 0,
  onUpload,
  onReview,
  onExport
}) => {
  const actions = [
    {
      id: 'upload',
      icon: Plus,
      label: 'Upload Resume',
      subtitle: 'Add new version',
      variant: 'primary', // gradient background
      onClick: onUpload
    },
    {
      id: 'review',
      icon: Zap,
      label: 'AI Review',
      subtitle: 'Get instant feedback',
      variant: 'secondary', // outlined with purple
      color: 'purple',
      onClick: onReview
    },
    {
      id: 'export',
      icon: Download,
      label: 'Export Report',
      subtitle: 'Download analytics',
      variant: 'secondary', // outlined with blue
      color: 'blue',
      onClick: onExport
    }
  ];

  const getButtonStyles = (action) => {
    if (action.variant === 'primary') {
      return {
        container: 'bg-gradient-to-r from-indigo-600 to-purple-600 hover:shadow-xl hover:shadow-indigo-500/30',
        iconBg: 'bg-white/20 backdrop-blur-sm',
        hoverOverlay: 'absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 opacity-0 group-hover/btn:opacity-100 transition-opacity'
      };
    }
    
    const colorMap = {
      purple: {
        border: 'border-slate-700/50 hover:border-purple-500/50',
        iconBg: 'bg-purple-500/10 border border-purple-500/20',
        iconColor: 'text-purple-400'
      },
      blue: {
        border: 'border-slate-700/50 hover:border-blue-500/50',
        iconBg: 'bg-blue-500/10 border border-blue-500/20',
        iconColor: 'text-blue-400'
      }
    };
    
    const colors = colorMap[action.color] || colorMap.purple;
    
    return {
      container: `bg-slate-800/50 border ${colors.border} hover:bg-slate-700/50`,
      iconBg: colors.iconBg,
      iconColor: colors.iconColor
    };
  };

  return (
    <div 
      className={`transform transition-all duration-700 ${isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="relative group h-full">
        {/* Glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-600/20 to-pink-600/20 rounded-3xl blur-2xl opacity-30"></div>
        
        {/* Card */}
        <div className="relative bg-gradient-to-br from-slate-900/90 via-slate-800/90 to-slate-900/90 backdrop-blur-xl border border-slate-700/50 rounded-3xl p-8 shadow-2xl h-full flex flex-col">
          {/* Header */}
          <h3 className="text-xl font-bold mb-6 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
            Quick Actions
          </h3>
          
          {/* Action Buttons */}
          <div className="space-y-3 flex-1">
            {actions.map((action) => {
              const styles = getButtonStyles(action);
              const Icon = action.icon;
              
              return (
                <button
                  key={action.id}
                  onClick={action.onClick}
                  className={`w-full group/btn relative overflow-hidden rounded-2xl p-5 text-left transition-all hover:scale-105 ${styles.container}`}
                  aria-label={action.label}
                >
                  {/* Hover overlay for primary button */}
                  {styles.hoverOverlay && (
                    <div className={styles.hoverOverlay}></div>
                  )}
                  
                  {/* Content */}
                  <div className="relative flex items-center gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center ${styles.iconBg}`}>
                      <Icon 
                        className={`w-6 h-6 ${styles.iconColor || ''}`} 
                        strokeWidth={2.5} 
                      />
                    </div>
                    <div>
                      <p className="font-bold text-base">{action.label}</p>
                      <p className={`text-xs ${action.variant === 'primary' ? 'text-indigo-100' : 'text-slate-400'}`}>
                        {action.subtitle}
                      </p>
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuickActions;