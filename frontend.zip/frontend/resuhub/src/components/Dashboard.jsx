import React, { useState, useEffect } from 'react';
import Navigation from './Navigation';
import WelcomeHeader from './Welcomeheader.jsx';
import StatCard from './Statcard.jsx';
import PerformanceChart from './Performancechart.jsx';
import QuickActions from './Quickactions.jsx';
import RecentResumes from './Recentresumes.jsx';
import { TrendingUp, Star, FileText, Zap } from 'lucide-react';

// Mock data - In production, this would come from an API
const mockResumes = [
  { id: 1, name: 'Software_Engineer_Resume_v3.pdf', score: 87, date: '2024-02-10', industry: 'Tech', views: 124 },
  { id: 2, name: 'Product_Manager_Resume.pdf', score: 82, date: '2024-02-08', industry: 'Business', views: 89 },
  { id: 3, name: 'Data_Analyst_Resume_Final.pdf', score: 79, date: '2024-02-05', industry: 'Analytics', views: 156 }
];

const Dashboard = () => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [activeNav, setActiveNav] = useState('dashboard');

  useEffect(() => {
    // Trigger animation on mount
    setIsLoaded(true);
  }, []);

  // Calculate statistics
  const avgScore = mockResumes.reduce((sum, r) => sum + r.score, 0) / mockResumes.length;
  const bestResume = mockResumes.reduce((best, r) => r.score > best.score ? r : best);
  const totalViews = mockResumes.reduce((sum, r) => sum + r.views, 0);

  const statsConfig = [
    {
      id: 'avg-score',
      icon: TrendingUp,
      label: 'Average ATS Score',
      subtitle: 'Across all resumes',
      value: Math.round(avgScore),
      badge: 'AVG',
      trend: '+5%',
      gradientFrom: 'indigo',
      gradientTo: 'purple',
      delay: 100
    },
    {
      id: 'best-score',
      icon: Star,
      label: 'Top Resume Score',
      subtitle: bestResume.name,
      value: bestResume.score,
      badge: 'BEST',
      trend: '★',
      gradientFrom: 'purple',
      gradientTo: 'pink',
      delay: 200,
      iconFill: true
    },
    {
      id: 'total-resumes',
      icon: FileText,
      label: 'Total Resumes',
      subtitle: 'Documents uploaded',
      value: mockResumes.length,
      badge: 'ALL',
      suffix: 'docs',
      gradientFrom: 'blue',
      gradientTo: 'cyan',
      delay: 300
    },
    {
      id: 'total-views',
      icon: Zap,
      label: 'Total Profile Views',
      subtitle: 'Last 30 days',
      value: totalViews,
      badge: 'VIEWS',
      trend: '+12%',
      gradientFrom: 'emerald',
      gradientTo: 'teal',
      delay: 400
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      {/* Navigation */}
      <Navigation activeNav={activeNav} onNavChange={setActiveNav} />

      {/* Main Content */}
      <div className="max-w-[1400px] mx-auto px-8 py-10">
        {/* Welcome Section */}
        <WelcomeHeader 
          userName="Name" 
          greeting="Good afternoon"
          isLoaded={isLoaded}
        />

        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-6 mb-10">
          {statsConfig.map((stat) => (
            <StatCard
              key={stat.id}
              {...stat}
              isLoaded={isLoaded}
            />
          ))}
        </div>

        {/* Performance Chart & Quick Actions */}
        <div className="grid grid-cols-3 gap-6 mb-10">
          <PerformanceChart 
            userScore={avgScore}
            percentile={15}
            isLoaded={isLoaded}
            delay={500}
          />
          <QuickActions 
            isLoaded={isLoaded}
            delay={600}
          />
        </div>

        {/* Recent Resumes */}
        <RecentResumes 
          resumes={mockResumes}
          isLoaded={isLoaded}
          delay={700}
        />
      </div>

      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
        
        * {
          font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
        }

        @media (prefers-reduced-motion: reduce) {
          * {
            animation-duration: 0.01ms !important;
            animation-iteration-count: 1 !important;
            transition-duration: 0.01ms !important;
          }
        }
      `}</style>
    </div>
  );
};

export default Dashboard;