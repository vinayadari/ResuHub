import React from 'react';

const WelcomeHeader = ({ userName, greeting = "Good afternoon", isLoaded = true }) => {
  return (
    <div className={`mb-10 transform transition-all duration-700 ${isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}>
      <h2 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
        {greeting}, {userName}
      </h2>
      <p className="text-slate-400 text-lg">
        Track your progress and optimize your career opportunities
      </p>
    </div>
  );
};

export default WelcomeHeader;