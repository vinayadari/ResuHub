import React from 'react';

/**
 * ResumeCard Component - Displays individual resume information
 * 
 * @param {Object} props
 * @param {Object} props.resume - Resume data object
 * @param {string} props.resume.name - Document name
 * @param {number} props.resume.score - ATS score (0-100)
 * @param {string} props.resume.date - Upload date
 * @param {string} props.resume.industry - Industry category
 * @param {number} props.resume.views - Number of views
 * @param {Function} [props.onClick] - Click handler
 */
const ResumeCard = ({ resume, onClick }) => {
  const getScoreStyles = (score) => {
    if (score >= 85) {
      return 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white';
    }
    if (score >= 75) {
      return 'bg-gradient-to-r from-amber-500 to-orange-500 text-white';
    }
    return 'bg-gradient-to-r from-red-500 to-rose-500 text-white';
  };

  return (
    <div 
      className="group/card relative overflow-hidden rounded-2xl bg-gradient-to-br from-slate-800/50 to-slate-900/50 border border-slate-700/50 p-6 hover:border-indigo-500/50 transition-all duration-300 cursor-pointer hover:scale-105 hover:shadow-xl hover:shadow-indigo-500/10"
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyPress={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          onClick?.();
        }
      }}
      aria-label={`Resume: ${resume.name}`}
    >
      {/* Score Badge - Top Right */}
      <div 
        className={`absolute top-4 right-4 px-3 py-1.5 rounded-xl font-bold text-sm shadow-lg ${getScoreStyles(resume.score)}`}
        aria-label={`Score: ${resume.score}`}
      >
        {resume.score}
      </div>

      {/* Content */}
      <div className="mb-4">
        <p className="text-xs text-slate-500 font-semibold mb-2">DOCUMENT</p>
        <p 
          className="text-base font-bold text-white mb-1 truncate group-hover/card:text-indigo-400 transition-colors"
          title={resume.name}
        >
          {resume.name}
        </p>
        <p className="text-xs text-slate-400">{resume.industry}</p>
      </div>
      
      {/* Stats Grid */}
      <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-700/50">
        <div>
          <p className="text-xs text-slate-500 mb-1">DATE</p>
          <p className="text-sm font-semibold text-slate-300">{resume.date}</p>
        </div>
        <div>
          <p className="text-xs text-slate-500 mb-1">VIEWS</p>
          <p className="text-sm font-semibold text-slate-300">{resume.views}</p>
        </div>
      </div>

      {/* Hover Overlay Effect */}
      <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/0 to-purple-600/0 group-hover/card:from-indigo-600/10 group-hover/card:to-purple-600/10 transition-all duration-300 pointer-events-none rounded-2xl"></div>
    </div>
  );
};

export default ResumeCard;