// Component exports for easy importing
export { default as Dashboard } from './Dashboard.jsx';
export { default as Navigation } from './Navigation.jsx';
export { default as WelcomeHeader } from './Welcomeheader.jsx';
export { default as StatCard } from './Statcard.jsx';
export { default as PerformanceChart } from './Performancechart.jsx';
export { default as QuickActions } from './Quickactions.jsx';
export { default as RecentResumes } from './Recentresumes.jsx';
export { default as ResumeCard } from './Resumecard.jsx';