import React from 'react';
import { ChevronDown } from 'lucide-react';
import ResumeCard from './ResumeCard';

/**
 * RecentResumes Component - Displays a grid of recent resume uploads
 * 
 * @param {Object} props
 * @param {Array} props.resumes - Array of resume objects
 * @param {boolean} [props.isLoaded=true] - Controls animation state
 * @param {number} [props.delay=0] - Animation delay in ms
 * @param {Function} [props.onViewAll] - Callback for "View All" button
 * @param {Function} [props.onResumeClick] - Callback when a resume card is clicked
 */
const RecentResumes = ({ 
  resumes = [], 
  isLoaded = true, 
  delay = 0,
  onViewAll,
  onResumeClick
}) => {
  return (
    <div 
      className={`transform transition-all duration-700 ${isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="relative group">
        {/* Glow effect */}
        <div className="absolute inset-0 bg-gradient-to-br from-indigo-600/10 to-purple-600/10 rounded-3xl blur-2xl"></div>
        
        {/* Card */}
        <div className="relative bg-gradient-to-br from-slate-900/90 via-slate-800/90 to-slate-900/90 backdrop-blur-xl border border-slate-700/50 rounded-3xl p-8 shadow-2xl">
          {/* Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-2xl font-bold mb-1 bg-gradient-to-r from-white to-slate-300 bg-clip-text text-transparent">
                Recent Resumes
              </h3>
              <p className="text-sm text-slate-400">Your latest uploaded documents</p>
            </div>
            
            {/* View All Button */}
            <button 
              onClick={onViewAll}
              className="px-6 py-3 rounded-xl bg-indigo-600/10 border border-indigo-500/30 text-indigo-400 font-semibold hover:bg-indigo-600/20 transition-all hover:scale-105 flex items-center gap-2"
              aria-label="View all resumes"
            >
              View All
              <ChevronDown className="w-4 h-4 rotate-[-90deg]" />
            </button>
          </div>
          
          {/* Resume Grid */}
          {resumes.length > 0 ? (
            <div className="grid grid-cols-3 gap-5">
              {resumes.map((resume) => (
                <ResumeCard 
                  key={resume.id} 
                  resume={resume}
                  onClick={() => onResumeClick?.(resume)}
                />
              ))}
            </div>
          ) : (
            // Empty state
            <div className="text-center py-12">
              <p className="text-slate-400 text-lg mb-2">No resumes uploaded yet</p>
              <p className="text-slate-500 text-sm">Upload your first resume to get started</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RecentResumes;