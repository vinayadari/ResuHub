import React from 'react';

/**
 * StatCard Component - Displays a metric with icon, label, value, and optional trend
 * 
 * @param {Object} props
 * @param {React.ComponentType} props.icon - Lucide icon component
 * @param {string} props.label - Main label text
 * @param {string} props.subtitle - Secondary descriptive text
 * @param {number|string} props.value - Main metric value
 * @param {string} props.badge - Badge text (e.g., "AVG", "BEST")
 * @param {string} [props.trend] - Trend indicator (e.g., "+5%", "★")
 * @param {string} [props.suffix] - Suffix for value (e.g., "docs")
 * @param {string} props.gradientFrom - Starting color of gradient (e.g., "indigo")
 * @param {string} props.gradientTo - Ending color of gradient (e.g., "purple")
 * @param {number} [props.delay=0] - Animation delay in ms
 * @param {boolean} [props.isLoaded=true] - Controls animation state
 * @param {boolean} [props.iconFill=false] - Whether to fill the icon
 */
const StatCard = ({
  icon: Icon,
  label,
  subtitle,
  value,
  badge,
  trend,
  suffix,
  gradientFrom,
  gradientTo,
  delay = 0,
  isLoaded = true,
  iconFill = false
}) => {
  // Color mapping for gradients
  const colorMap = {
    indigo: { from: 'from-indigo-600', to: 'to-purple-600', iconBg: 'from-indigo-500/20 to-purple-500/20', iconBorder: 'border-indigo-500/30', iconColor: 'text-indigo-400', badgeBg: 'bg-indigo-500/10', badgeBorder: 'border-indigo-500/20', badgeText: 'text-indigo-400', valueGradient: 'from-indigo-400 via-purple-400 to-pink-400' },
    purple: { from: 'from-purple-600', to: 'to-pink-600', iconBg: 'from-purple-500/20 to-pink-500/20', iconBorder: 'border-purple-500/30', iconColor: 'text-purple-400', badgeBg: 'bg-purple-500/10', badgeBorder: 'border-purple-500/20', badgeText: 'text-purple-400', valueGradient: 'from-purple-400 via-pink-400 to-rose-400', trendColor: 'text-amber-400' },
    blue: { from: 'from-blue-600', to: 'to-cyan-600', iconBg: 'from-blue-500/20 to-cyan-500/20', iconBorder: 'border-blue-500/30', iconColor: 'text-blue-400', badgeBg: 'bg-blue-500/10', badgeBorder: 'border-blue-500/20', badgeText: 'text-blue-400', valueGradient: 'from-blue-400 via-cyan-400 to-teal-400', suffixColor: 'text-slate-500' },
    emerald: { from: 'from-emerald-600', to: 'to-teal-600', iconBg: 'from-emerald-500/20 to-teal-500/20', iconBorder: 'border-emerald-500/30', iconColor: 'text-emerald-400', badgeBg: 'bg-emerald-500/10', badgeBorder: 'border-emerald-500/20', badgeText: 'text-emerald-400', valueGradient: 'from-emerald-400 via-teal-400 to-cyan-400', trendColor: 'text-emerald-400' }
  };

  const colors = colorMap[gradientFrom] || colorMap.indigo;

  return (
    <div 
      className={`transform transition-all duration-700 ${isLoaded ? 'translate-y-0 opacity-100' : 'translate-y-4 opacity-0'}`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className="relative group">
        {/* Glow effect */}
        <div className={`absolute inset-0 bg-gradient-to-br ${colors.from} ${colors.to} rounded-3xl blur-xl opacity-20 group-hover:opacity-30 transition-opacity`}></div>
        
        {/* Card */}
        <div className="relative bg-gradient-to-br from-slate-900/90 via-slate-800/90 to-slate-900/90 backdrop-blur-xl border border-slate-700/50 rounded-3xl p-7 shadow-2xl">
          {/* Icon & Badge Row */}
          <div className="flex items-start justify-between mb-6">
            {/* Icon */}
            <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${colors.iconBg} border ${colors.iconBorder} flex items-center justify-center group-hover:scale-110 transition-transform duration-500`}>
              <Icon 
                className={`w-7 h-7 ${colors.iconColor}`} 
                strokeWidth={2.5}
                fill={iconFill ? "currentColor" : "none"}
              />
            </div>
            
            {/* Badge */}
            <div className={`px-3 py-1 rounded-lg ${colors.badgeBg} border ${colors.badgeBorder}`}>
              <span className={`text-xs font-bold ${colors.badgeText}`}>
                {badge}
              </span>
            </div>
          </div>
          
          {/* Labels */}
          <div className="mb-2">
            <p className="text-sm text-slate-400 font-semibold mb-1">{label}</p>
            <p className="text-xs text-slate-500 truncate" title={subtitle}>
              {subtitle}
            </p>
          </div>
          
          {/* Value & Trend/Suffix */}
          <div className="flex items-baseline gap-2">
            <p className={`text-5xl font-bold bg-gradient-to-r ${colors.valueGradient} bg-clip-text text-transparent`}>
              {value}
            </p>
            {trend && (
              <span className={`text-sm font-semibold ${colors.trendColor || 'text-emerald-400'}`}>
                {trend}
              </span>
            )}
            {suffix && (
              <span className={`text-sm font-semibold ${colors.suffixColor || 'text-slate-500'}`}>
                {suffix}
              </span>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default StatCard;