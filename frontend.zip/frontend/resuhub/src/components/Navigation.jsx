import React, { useState } from 'react';
import { Bell, ChevronDown, Award } from 'lucide-react';

const Navigation = ({ activeNav, onNavChange }) => {
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const navItems = ['Dashboard', 'Versions', 'Resumes', 'AI Review'];

  const handleNavClick = (item) => {
    onNavChange(item.toLowerCase().replace(' ', ''));
  };

  return (
    <nav className="border-b border-white/5 bg-slate-900/40 backdrop-blur-2xl sticky top-0 z-50">
      <div className="max-w-[1400px] mx-auto px-8 py-4">
        <div className="flex items-center justify-between">
          {/* Logo Section */}
          <div className="flex items-center gap-6">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-2xl blur-xl opacity-50 group-hover:opacity-75 transition-opacity"></div>
              <div className="relative w-14 h-14 bg-gradient-to-br from-indigo-500 via-purple-500 to-pink-500 rounded-2xl flex items-center justify-center shadow-2xl">
                <Award className="w-7 h-7 text-white" strokeWidth={2.5} />
              </div>
            </div>
            <div>
              <h1 className="text-2xl font-bold tracking-tight">
                <span className="bg-gradient-to-r from-indigo-300 via-purple-300 to-pink-300 bg-clip-text text-transparent">
                  ResuHub
                </span>
              </h1>
              <p className="text-xs text-slate-400 font-medium">Professional Resume Intelligence</p>
            </div>
          </div>

          {/* Navigation Links */}
          <div className="flex items-center gap-2 bg-slate-800/30 rounded-2xl p-1.5">
            {navItems.map((item) => (
              <button
                key={item}
                onClick={() => handleNavClick(item)}
                className={`px-6 py-2.5 rounded-xl font-semibold transition-all duration-300 ${
                  activeNav === item.toLowerCase().replace(' ', '')
                    ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30 scale-105'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                {item}
              </button>
            ))}
          </div>

          {/* Right Section - Notifications & Profile */}
          <div className="flex items-center gap-4">
            {/* Notification Bell */}
            <button 
              className="w-11 h-11 rounded-xl bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700/50 flex items-center justify-center transition-all hover:scale-105"
              aria-label="Notifications"
            >
              <Bell className="w-5 h-5 text-slate-300" />
            </button>
            
            {/* Profile Dropdown */}
            <div className="relative">
              <button 
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-3 px-4 py-2.5 rounded-xl bg-slate-800/50 hover:bg-slate-700/50 border border-slate-700/50 transition-all hover:scale-105"
                aria-label="Profile menu"
                aria-expanded={showProfileMenu}
              >
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-500 flex items-center justify-center font-bold shadow-lg">
                  U
                </div>
                <span className="text-sm font-semibold">Profile</span>
                <ChevronDown className={`w-4 h-4 text-slate-400 transition-transform duration-300 ${showProfileMenu ? 'rotate-180' : ''}`} />
              </button>
              
              {/* Dropdown Menu */}
              {showProfileMenu && (
                <>
                  {/* Backdrop */}
                  <div 
                    className="fixed inset-0 z-40" 
                    onClick={() => setShowProfileMenu(false)}
                    aria-hidden="true"
                  />
                  
                  {/* Menu */}
                  <div className="absolute right-0 mt-3 w-56 rounded-2xl bg-slate-800 border border-slate-700/50 shadow-2xl overflow-hidden z-50 animate-slideDown">
                    {/* User Info Header */}
                    <div className="p-3 border-b border-slate-700/50">
                      <p className="font-semibold text-sm">User Name</p>
                      <p className="text-xs text-slate-400">user@example.com</p>
                    </div>
                    
                    {/* Menu Items */}
                    <div className="py-2">
                      <button className="w-full px-4 py-2.5 text-left text-sm hover:bg-slate-700/50 transition-colors font-medium">
                        Settings
                      </button>
                      <button className="w-full px-4 py-2.5 text-left text-sm hover:bg-slate-700/50 transition-colors font-medium">
                        Billing
                      </button>
                      <button className="w-full px-4 py-2.5 text-left text-sm hover:bg-slate-700/50 transition-colors font-medium">
                        Help Center
                      </button>
                    </div>
                    
                    {/* Logout */}
                    <div className="border-t border-slate-700/50">
                      <button className="w-full px-4 py-2.5 text-left text-sm text-red-400 hover:bg-red-500/10 transition-colors font-medium">
                        Logout
                      </button>
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideDown {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        .animate-slideDown {
          animation: slideDown 0.2s ease-out;
        }
      `}</style>
    </nav>
  );
};

export default Navigation;