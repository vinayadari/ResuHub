import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route, useNavigate } from 'react-router-dom';
import { 
  Navigation, 
  WelcomeHeader, 
  StatCard,
  PerformanceChart,
  QuickActions,
  RecentResumes 
} from './components';
import { TrendingUp, Star, FileText, Zap } from 'lucide-react';

// Main Dashboard Page
function DashboardPage() {
  const navigate = useNavigate();
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [activeNav, setActiveNav] = useState('dashboard');
  const [isLoaded, setIsLoaded] = useState(false);

  // Fetch resumes from API
  useEffect(() => {
    async function fetchResumes() {
      try {
        // Replace with your actual API endpoint
        const response = await fetch('/api/resumes');
        
        // If API not ready, use mock data
        if (!response.ok) {
          throw new Error('API not available, using mock data');
        }
        
        const data = await response.json();
        setResumes(data);
      } catch (error) {
        console.warn('Using mock data:', error.message);
        
        // Mock data fallback
        setResumes([
          { id: 1, name: 'Software_Engineer_Resume_v3.pdf', score: 87, date: '2024-02-10', industry: 'Tech', views: 124 },
          { id: 2, name: 'Product_Manager_Resume.pdf', score: 82, date: '2024-02-08', industry: 'Business', views: 89 },
          { id: 3, name: 'Data_Analyst_Resume_Final.pdf', score: 79, date: '2024-02-05', industry: 'Analytics', views: 156 },
          { id: 4, name: 'UX_Designer_Portfolio_2024.pdf', score: 91, date: '2024-02-01', industry: 'Design', views: 203 },
          { id: 5, name: 'DevOps_Engineer_Resume.pdf', score: 85, date: '2024-01-28', industry: 'Tech', views: 145 }
        ]);
      } finally {
        setLoading(false);
        setTimeout(() => setIsLoaded(true), 100);
      }
    }
    
    fetchResumes();
  }, []);

  // Calculate statistics
  const avgScore = resumes.length > 0 
    ? resumes.reduce((sum, r) => sum + r.score, 0) / resumes.length 
    : 0;
  
  const bestResume = resumes.length > 0
    ? resumes.reduce((best, r) => r.score > best.score ? r : best)
    : { name: 'No resumes', score: 0 };
  
  const totalViews = resumes.reduce((sum, r) => sum + r.views, 0);

  // Stats configuration
  const statsConfig = [
    {
      id: 'avg-score',
      icon: TrendingUp,
      label: 'Average ATS Score',
      subtitle: 'Across all resumes',
      value: Math.round(avgScore),
      badge: 'AVG',
      trend: '+5%',
      gradientFrom: 'indigo',
      gradientTo: 'purple',
      delay: 100
    },
    {
      id: 'best-score',
      icon: Star,
      label: 'Top Resume Score',
      subtitle: bestResume.name,
      value: bestResume.score,
      badge: 'BEST',
      trend: '★',
      gradientFrom: 'purple',
      gradientTo: 'pink',
      delay: 200,
      iconFill: true
    },
    {
      id: 'total-resumes',
      icon: FileText,
      label: 'Total Resumes',
      subtitle: 'Documents uploaded',
      value: resumes.length,
      badge: 'ALL',
      suffix: 'docs',
      gradientFrom: 'blue',
      gradientTo: 'cyan',
      delay: 300
    },
    {
      id: 'total-views',
      icon: Zap,
      label: 'Total Profile Views',
      subtitle: 'Last 30 days',
      value: totalViews,
      badge: 'VIEWS',
      trend: '+12%',
      gradientFrom: 'emerald',
      gradientTo: 'teal',
      delay: 400
    }
  ];

  // Event handlers
  const handleUpload = () => {
    navigate('/upload');
  };

  const handleReview = () => {
    navigate('/ai-review');
  };

  const handleExport = async () => {
    try {
      // Replace with your actual API endpoint
      const response = await fetch('/api/export', { 
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ resumes: resumes.map(r => r.id) })
      });
      
      if (!response.ok) {
        throw new Error('Export failed');
      }
      
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `resume-analytics-${new Date().toISOString().split('T')[0]}.pdf`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
      
      alert('Report exported successfully!');
    } catch (error) {
      console.error('Export failed:', error);
      alert('Export feature coming soon! (API not connected)');
    }
  };

  const handleResumeClick = (resume) => {
    navigate(`/resume/${resume.id}`);
  };

  const handleViewAll = () => {
    navigate('/resumes');
  };

  const handleNavChange = (nav) => {
    setActiveNav(nav);
    
    // Navigate based on selection
    switch(nav) {
      case 'dashboard':
        navigate('/');
        break;
      case 'versions':
        navigate('/versions');
        break;
      case 'resumes':
        navigate('/resumes');
        break;
      case 'aireview':
        navigate('/ai-review');
        break;
      default:
        navigate('/');
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
          <p className="text-xl font-semibold">Loading your dashboard...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white flex items-center justify-center">
        <div className="text-center">
          <p className="text-xl font-semibold text-red-400 mb-4">Error loading dashboard</p>
          <p className="text-slate-400">{error}</p>
          <button 
            onClick={() => window.location.reload()} 
            className="mt-4 px-6 py-3 bg-indigo-600 hover:bg-indigo-700 rounded-xl transition-colors"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      <Navigation activeNav={activeNav} onNavChange={handleNavChange} />
      
      <div className="max-w-[1400px] mx-auto px-8 py-10">
        {/* Welcome Section */}
        <WelcomeHeader 
          userName="User" 
          greeting="Good afternoon"
          isLoaded={isLoaded}
        />

        {/* Stats Grid */}
        <div className="grid grid-cols-4 gap-6 mb-10">
          {statsConfig.map((stat) => (
            <StatCard
              key={stat.id}
              {...stat}
              isLoaded={isLoaded}
            />
          ))}
        </div>

        {/* Performance Chart & Quick Actions */}
        <div className="grid grid-cols-3 gap-6 mb-10">
          <PerformanceChart 
            userScore={avgScore}
            percentile={15}
            isLoaded={isLoaded}
            delay={500}
          />
          <QuickActions 
            isLoaded={isLoaded}
            delay={600}
            onUpload={handleUpload}
            onReview={handleReview}
            onExport={handleExport}
          />
        </div>

        {/* Recent Resumes */}
        <RecentResumes 
          resumes={resumes.slice(0, 3)}
          isLoaded={isLoaded}
          delay={700}
          onViewAll={handleViewAll}
          onResumeClick={handleResumeClick}
        />
      </div>
    </div>
  );
}

// Upload Page
function UploadPage() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('dashboard');
  const [dragActive, setDragActive] = useState(false);
  const [file, setFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = async () => {
    if (!file) return;

    setUploading(true);
    
    try {
      const formData = new FormData();
      formData.append('resume', file);

      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Upload failed');
      }

      const data = await response.json();
      alert(`Resume uploaded successfully! Score: ${data.score}`);
      navigate('/');
    } catch (error) {
      console.error('Upload error:', error);
      alert('Upload feature coming soon! (API not connected)');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      <Navigation activeNav={activeNav} onNavChange={(nav) => {
        setActiveNav(nav);
        if (nav === 'dashboard') navigate('/');
      }} />
      
      <div className="max-w-[800px] mx-auto px-8 py-10">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
          Upload Resume
        </h1>
        <p className="text-slate-400 text-lg mb-10">Upload your resume to get ATS score and feedback</p>

        {/* Upload Area */}
        <div 
          className={`relative border-2 border-dashed rounded-3xl p-12 text-center transition-all ${
            dragActive 
              ? 'border-indigo-500 bg-indigo-500/10' 
              : 'border-slate-700 hover:border-slate-600'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            type="file"
            id="file-upload"
            className="hidden"
            accept=".pdf,.doc,.docx"
            onChange={handleFileChange}
          />
          
          {file ? (
            <div className="space-y-4">
              <div className="w-20 h-20 mx-auto bg-gradient-to-br from-emerald-500 to-teal-500 rounded-2xl flex items-center justify-center">
                <FileText className="w-10 h-10" />
              </div>
              <p className="text-xl font-semibold">{file.name}</p>
              <p className="text-slate-400">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
              
              <div className="flex gap-4 justify-center mt-6">
                <button
                  onClick={handleUpload}
                  disabled={uploading}
                  className="px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 rounded-xl font-semibold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {uploading ? 'Uploading...' : 'Upload Resume'}
                </button>
                <button
                  onClick={() => setFile(null)}
                  className="px-8 py-3 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-xl font-semibold transition-all"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <>
              <div className="w-20 h-20 mx-auto bg-slate-800 rounded-2xl flex items-center justify-center mb-4">
                <FileText className="w-10 h-10 text-slate-400" />
              </div>
              <p className="text-xl font-semibold mb-2">Drag and drop your resume here</p>
              <p className="text-slate-400 mb-6">or</p>
              <label
                htmlFor="file-upload"
                className="inline-block px-8 py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 rounded-xl font-semibold cursor-pointer transition-all"
              >
                Browse Files
              </label>
              <p className="text-sm text-slate-500 mt-4">Supported formats: PDF, DOC, DOCX (Max 10MB)</p>
            </>
          )}
        </div>
      </div>
    </div>
  );
}

// AI Review Page
function AIReviewPage() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('aireview');
  const [selectedResume, setSelectedResume] = useState(null);
  const [reviewing, setReviewing] = useState(false);
  const [review, setReview] = useState(null);

  const mockResumes = [
    { id: 1, name: 'Software_Engineer_Resume_v3.pdf', score: 87 },
    { id: 2, name: 'Product_Manager_Resume.pdf', score: 82 },
    { id: 3, name: 'Data_Analyst_Resume_Final.pdf', score: 79 }
  ];

  const handleReview = async () => {
    if (!selectedResume) return;

    setReviewing(true);
    
    try {
      const response = await fetch(`/api/review/${selectedResume}`, {
        method: 'POST'
      });

      if (!response.ok) {
        throw new Error('Review failed');
      }

      const data = await response.json();
      setReview(data);
    } catch (error) {
      console.error('Review error:', error);
      // Mock review data
      setReview({
        strengths: [
          'Clear and concise formatting',
          'Relevant keywords for ATS',
          'Quantifiable achievements'
        ],
        improvements: [
          'Add more specific metrics',
          'Include relevant certifications',
          'Optimize for specific job descriptions'
        ],
        score: 87
      });
    } finally {
      setReviewing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      <Navigation activeNav={activeNav} onNavChange={(nav) => {
        setActiveNav(nav);
        if (nav === 'dashboard') navigate('/');
      }} />
      
      <div className="max-w-[1000px] mx-auto px-8 py-10">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
          AI Resume Review
        </h1>
        <p className="text-slate-400 text-lg mb-10">Get instant AI-powered feedback on your resume</p>

        {/* Resume Selection */}
        <div className="bg-slate-900/50 border border-slate-700/50 rounded-3xl p-8 mb-6">
          <h2 className="text-xl font-bold mb-4">Select a Resume</h2>
          <div className="space-y-3">
            {mockResumes.map((resume) => (
              <button
                key={resume.id}
                onClick={() => setSelectedResume(resume.id)}
                className={`w-full p-4 rounded-xl text-left transition-all ${
                  selectedResume === resume.id
                    ? 'bg-indigo-600 border-2 border-indigo-500'
                    : 'bg-slate-800/50 border-2 border-slate-700/50 hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="font-semibold">{resume.name}</span>
                  <span className="px-3 py-1 bg-emerald-500/20 text-emerald-400 rounded-lg text-sm font-bold">
                    {resume.score}
                  </span>
                </div>
              </button>
            ))}
          </div>

          <button
            onClick={handleReview}
            disabled={!selectedResume || reviewing}
            className="w-full mt-6 px-8 py-4 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 rounded-xl font-bold text-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {reviewing ? 'Analyzing...' : 'Start AI Review'}
          </button>
        </div>

        {/* Review Results */}
        {review && (
          <div className="bg-slate-900/50 border border-slate-700/50 rounded-3xl p-8">
            <h2 className="text-2xl font-bold mb-6">Review Results</h2>
            
            <div className="grid grid-cols-2 gap-6">
              <div>
                <h3 className="text-lg font-semibold text-emerald-400 mb-3">✓ Strengths</h3>
                <ul className="space-y-2">
                  {review.strengths.map((strength, i) => (
                    <li key={i} className="text-slate-300 flex items-start gap-2">
                      <span className="text-emerald-400">•</span>
                      {strength}
                    </li>
                  ))}
                </ul>
              </div>

              <div>
                <h3 className="text-lg font-semibold text-amber-400 mb-3">→ Improvements</h3>
                <ul className="space-y-2">
                  {review.improvements.map((improvement, i) => (
                    <li key={i} className="text-slate-300 flex items-start gap-2">
                      <span className="text-amber-400">•</span>
                      {improvement}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// All Resumes Page
function AllResumesPage() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('resumes');
  
  const allResumes = [
    { id: 1, name: 'Software_Engineer_Resume_v3.pdf', score: 87, date: '2024-02-10', industry: 'Tech', views: 124 },
    { id: 2, name: 'Product_Manager_Resume.pdf', score: 82, date: '2024-02-08', industry: 'Business', views: 89 },
    { id: 3, name: 'Data_Analyst_Resume_Final.pdf', score: 79, date: '2024-02-05', industry: 'Analytics', views: 156 },
    { id: 4, name: 'UX_Designer_Portfolio_2024.pdf', score: 91, date: '2024-02-01', industry: 'Design', views: 203 },
    { id: 5, name: 'DevOps_Engineer_Resume.pdf', score: 85, date: '2024-01-28', industry: 'Tech', views: 145 },
    { id: 6, name: 'Marketing_Manager_CV.pdf', score: 88, date: '2024-01-25', industry: 'Marketing', views: 167 }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      <Navigation activeNav={activeNav} onNavChange={(nav) => {
        setActiveNav(nav);
        if (nav === 'dashboard') navigate('/');
      }} />
      
      <div className="max-w-[1400px] mx-auto px-8 py-10">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
          All Resumes
        </h1>
        <p className="text-slate-400 text-lg mb-10">Manage and review all your uploaded resumes</p>

        <RecentResumes 
          resumes={allResumes}
          isLoaded={true}
          onResumeClick={(resume) => navigate(`/resume/${resume.id}`)}
        />
      </div>
    </div>
  );
}

// Resume Detail Page
function ResumeDetailPage() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('resumes');
  
  const resume = {
    id: 1,
    name: 'Software_Engineer_Resume_v3.pdf',
    score: 87,
    date: '2024-02-10',
    industry: 'Tech',
    views: 124,
    keywords: ['React', 'Node.js', 'TypeScript', 'AWS', 'Docker'],
    sections: {
      contact: 'Present',
      summary: 'Strong',
      experience: 'Excellent',
      education: 'Present',
      skills: 'Good'
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      <Navigation activeNav={activeNav} onNavChange={(nav) => {
        setActiveNav(nav);
        if (nav === 'dashboard') navigate('/');
      }} />
      
      <div className="max-w-[1000px] mx-auto px-8 py-10">
        <button 
          onClick={() => navigate('/resumes')}
          className="mb-6 text-indigo-400 hover:text-indigo-300 transition-colors"
        >
          ← Back to All Resumes
        </button>

        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
          {resume.name}
        </h1>
        <p className="text-slate-400 text-lg mb-10">{resume.industry} • Uploaded {resume.date}</p>

        <div className="grid grid-cols-3 gap-6 mb-6">
          <StatCard
            icon={Star}
            label="ATS Score"
            subtitle="Performance rating"
            value={resume.score}
            badge="SCORE"
            gradientFrom="purple"
            gradientTo="pink"
            iconFill={true}
            isLoaded={true}
          />
          <StatCard
            icon={FileText}
            label="Total Views"
            subtitle="Profile impressions"
            value={resume.views}
            badge="VIEWS"
            gradientFrom="blue"
            gradientTo="cyan"
            isLoaded={true}
          />
          <StatCard
            icon={Zap}
            label="Keywords"
            subtitle="Detected terms"
            value={resume.keywords.length}
            badge="KEYWORDS"
            gradientFrom="emerald"
            gradientTo="teal"
            isLoaded={true}
          />
        </div>

        <div className="bg-slate-900/50 border border-slate-700/50 rounded-3xl p-8">
          <h2 className="text-2xl font-bold mb-6">Resume Analysis</h2>
          
          <div className="space-y-4">
            {Object.entries(resume.sections).map(([section, status]) => (
              <div key={section} className="flex items-center justify-between p-4 bg-slate-800/50 rounded-xl">
                <span className="font-semibold capitalize">{section}</span>
                <span className={`px-3 py-1 rounded-lg text-sm font-bold ${
                  status === 'Excellent' ? 'bg-emerald-500/20 text-emerald-400' :
                  status === 'Strong' || status === 'Good' ? 'bg-blue-500/20 text-blue-400' :
                  'bg-slate-500/20 text-slate-400'
                }`}>
                  {status}
                </span>
              </div>
            ))}
          </div>

          <div className="mt-6">
            <h3 className="font-semibold mb-3">Detected Keywords</h3>
            <div className="flex flex-wrap gap-2">
              {resume.keywords.map((keyword, i) => (
                <span key={i} className="px-3 py-1 bg-indigo-500/20 text-indigo-400 rounded-lg text-sm">
                  {keyword}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Versions Page
function VersionsPage() {
  const navigate = useNavigate();
  const [activeNav, setActiveNav] = useState('versions');

  const versions = [
    { id: 1, version: 'v3', name: 'Software_Engineer_Resume_v3.pdf', score: 87, date: '2024-02-10', changes: 'Updated skills section' },
    { id: 2, version: 'v2', name: 'Software_Engineer_Resume_v2.pdf', score: 82, date: '2024-01-15', changes: 'Added new project' },
    { id: 3, version: 'v1', name: 'Software_Engineer_Resume_v1.pdf', score: 78, date: '2024-01-01', changes: 'Initial version' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-indigo-950 via-slate-900 to-indigo-900 text-white">
      <Navigation activeNav={activeNav} onNavChange={(nav) => {
        setActiveNav(nav);
        if (nav === 'dashboard') navigate('/');
      }} />
      
      <div className="max-w-[1000px] mx-auto px-8 py-10">
        <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-white via-slate-100 to-slate-300 bg-clip-text text-transparent">
          Resume Versions
        </h1>
        <p className="text-slate-400 text-lg mb-10">Track changes and improvements across versions</p>

        <div className="space-y-4">
          {versions.map((version, index) => (
            <div key={version.id} className="relative bg-slate-900/50 border border-slate-700/50 rounded-2xl p-6 hover:border-indigo-500/50 transition-all">
              <div className="flex items-center justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="px-3 py-1 bg-indigo-500/20 text-indigo-400 rounded-lg font-bold text-sm">
                      {version.version}
                    </span>
                    {index === 0 && (
                      <span className="px-2 py-0.5 bg-emerald-500/20 text-emerald-400 rounded text-xs font-bold">
                        LATEST
                      </span>
                    )}
                  </div>
                  <h3 className="text-lg font-semibold mb-1">{version.name}</h3>
                  <p className="text-sm text-slate-400 mb-2">{version.changes}</p>
                  <p className="text-xs text-slate-500">{version.date}</p>
                </div>
                
                <div className="text-right">
                  <div className={`text-3xl font-bold mb-2 ${
                    version.score >= 85 ? 'text-emerald-400' :
                    version.score >= 75 ? 'text-blue-400' :
                    'text-amber-400'
                  }`}>
                    {version.score}
                  </div>
                  <button className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 rounded-lg text-sm font-semibold transition-colors">
                    View Details
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// Main App with Router
function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<DashboardPage />} />
        <Route path="/upload" element={<UploadPage />} />
        <Route path="/ai-review" element={<AIReviewPage />} />
        <Route path="/resumes" element={<AllResumesPage />} />
        <Route path="/resume/:id" element={<ResumeDetailPage />} />
        <Route path="/versions" element={<VersionsPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;